"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./src/data/sections/services.json":
/*!*****************************************!*\
  !*** ./src/data/sections/services.json ***!
  \*****************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

module.exports = JSON.parse('{"bg_image":"img/content/3.jpg","items":[{"num":"01","title":"Website Content","icon":"img/icons/1.svg","text":"Deleniti ratione, delectus beatae, exercitationem debitis, dignissimos similique, atque, officiis.","link":"/services/website-content"},{"num":"02","title":"Blog Articles","icon":"img/icons/2.svg","text":"Deleniti ratione, delectus beatae, exercitationem debitis, dignissimos similique, atque, officiis.","link":"/services/blog-articles"},{"num":"03","title":"Product Captions","icon":"img/icons/3.svg","text":"Deleniti ratione, delectus beatae, exercitationem debitis, dignissimos similique, atque, officiis.","link":"/services/product-captions"},{"num":"04","title":"Email Writing","icon":"img/icons/4.svg","text":"Deleniti ratione, delectus beatae, exercitationem debitis, dignissimos similique, atque, officiis.","link":"/services/email-writing"}]}');

/***/ })

});