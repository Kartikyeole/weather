"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./src/data/sections/hero-1.json":
/*!***************************************!*\
  !*** ./src/data/sections/hero-1.json ***!
  \***************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

module.exports = JSON.parse('{"bg_image":"img/hero/1.jpg","subtitle":"Welcome friend!","title":{"before":"IOIT","accent":"MUN","after":"In association "},"description":"Dicta sunt explicabo. Nemo enim ipsam <br />voluptatem quia voluptas sit","image":"img/hero/2.jpg","partners":[{"image":"img/partners/1.svg","link":"#.","alt":"logo"},{"image":"img/partners/2.svg","link":"#.","alt":"logo"},{"image":"img/partners/3.svg","link":"#.","alt":"logo"},{"image":"img/partners/4.svg","link":"#.","alt":"logo"},{"image":"img/partners/5.svg","link":"#.","alt":"logo"},{"image":"img/partners/6.svg","link":"#.","alt":"logo"},{"image":"img/partners/7.svg","link":"#.","alt":"logo"},{"image":"img/partners/8.svg","link":"#.","alt":"logo"}]}');

/***/ })

});